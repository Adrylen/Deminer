/*
    Java Project
    Deminer
    Package : org.game.graphics.events

    Created by adrylen on 10/03/17.
*/

package org.game.graphics.events;

import java.awt.event.MouseAdapter;

public class MouseEvent extends MouseAdapter{

}
