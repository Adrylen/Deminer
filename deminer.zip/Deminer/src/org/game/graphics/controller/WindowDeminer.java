/*
    Java Project
    Deminer
    Package : org.game.graphics

    Created by adrylen on 10/03/17.
*/

package org.game.graphics.controller;

import org.game.graphics.view.Window;



public class WindowDeminer {
	public void launch() {

	}

	public void test() {
            new Window("Deminer").main();
	}
}
